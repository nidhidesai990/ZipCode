/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//check zipcode
function zip(zipcode) {


    $.ajax({
        url: '/ZipCode/ZipController?Zipcode=' + zipcode,
        type: 'GET',
//        Zipcode:zipcode,
        success: function (responseText) {

            $("#Ajax_response_zip").text(responseText);
            if (responseText != "ZipCode Matched!") {
                flag_zip = false;
            }
            else{
                flag_zip=true;
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            $("#Ajax_response_zip").text("Failed");
        },
    });

}

$(document).ready(function () {

    shipping("product");
});
//validate weigth
function weigth() {

    LB = document.getElementById('LB').value;
    OZ = document.getElementById('OZ').value;

    if (LB > 25 || OZ > 18) {
        $("#OZ").css({"color": "red"});
        $("#LB").css({"color": "red"});
        flag_weigth = false;
    }
    else {
        flag_weigth = true;
        $("#OZ").css({"color": "white"});
        $("#LB").css({"color": "white"});

    }

}
//validate weigth
function weigth_size1() {

    weigth_ = document.getElementById('w_size').value;
    length_ = document.getElementById('l_size').value;
    heigth_ = document.getElementById('h_size').value;
    if (weigth_ > 17 || heigth_ > 17 || length_ > 17) {
        $("#w_size").css({"color": "red"});
        $("#l_size").css({"color": "red"});
        $("#h_size").css({"color": "red"});
        flag_size = false;
    }
    else {
        $("#w_size").css({"color": "white"});
        $("#l_size").css({"color": "white"});
        $("#h_size").css({"color": "white"});
        flag_size = true;
    }
}


//onsubmit validation
function submit_() {
  
  
    if (flag_zip == true && flag_size==true && flag_weigth==true) {
        $('#Submit_msg').text("You can ship the item!!");
        $("#Submit_msg").css({"color": "green"});
        return true;
    }
    else {
        $('#Submit_msg').text("You can not ship the item");
        $("#Submit_msg").css({"color": "red"});
        return false;
    }

}
//ajax to retrive shipping
function shipping(mode) {

    $.ajax({
        url: '/ZipCode/ZipController?mode=' + mode,
        type: 'GET',
//        Zipcode:zipcode,
        success: function (responseText) {
            category = JSON.parse(responseText);

            $.each(category, function (key, value) {
                $('#category')
                        .append($("<option></option>")
                                .attr("value", value)
                                .text(value));
            });
//            $("#Ajax_response_zip").text(responseText);
        },
        error: function (jqXHR, textStatus, errorThrown) {
//            $("#Ajax_response_zip").text("Failed");
        },
    });
}