/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Set;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletContext;

/**
 *
 * @author Nidhi Desai
 */
// get the values from csv file
public class GetZip {

    public boolean zip(int zipcode,String file) throws FileNotFoundException, IOException, NamingException {

        String Line = null;
        int zip = 0;
        
        boolean match = false;
        System.out.println("Zip called");
//        File f=new File(file);
//        System.out.println(f.getAbsolutePath());
     
//        String file = (String) initialcontext.lookup("java:comp/env/Zipfile");
        BufferedReader br = new BufferedReader(new FileReader(file));
        while ((Line = br.readLine()) != null) {
            String[] a = Line.split(",");
            zip = Integer.parseInt(a[0]);
            if (zipcode == zip) {
                match = true;
                break;
            }

        }
        return match;
    }

   
}
