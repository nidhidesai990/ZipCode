/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Nidhi Desai
 */
public class Item_category {

private String path;

    public Item_category(String path) {
        this.path=path;
    }

    public ArrayList<String> category_item() throws FileNotFoundException, IOException {
        BufferedReader br = new BufferedReader(new FileReader(this.path));
        String Line = null;
        ArrayList<String> cate_item = new ArrayList<>();
        while ((Line = br.readLine()) != null) {
            String[] a = Line.split(",");
            cate_item.add(a[0]);
        }
        return cate_item;
    }
   
}
