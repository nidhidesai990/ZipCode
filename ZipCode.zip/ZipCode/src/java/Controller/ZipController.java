/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.GetZip;
import Model.Item_category;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import static java.security.AccessController.getContext;
import java.util.ArrayList;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.RequestWrapper;

/**
 *
 * @author Nidhi Desai
 */
public class ZipController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, FileNotFoundException {
//        processRequest(request, response);
        try {

            String path = request.getServletContext().getRealPath("/");
            if (request.getParameter("Zipcode") != null) {
                path = path + "Files\\us_postal_codes.csv";
                GetZip zip = new GetZip();
                boolean match = zip.zip(Integer.parseInt(request.getParameter("Zipcode")), path);
                String res = null;

                if (match) {

                    res = "ZipCode Matched!";
                } else {
                    res = "Incorrect ZipCode or Sevice is not Available in this area!!";

                }
                response.setContentType("text/plain");
                response.getWriter().write(res);
            }
            if (request.getParameter("mode") != null) {
                String res = null;
                path = path + "Files\\item_category.csv";
                ArrayList<String> cate = this.category(path);
                String json = new Gson().toJson(cate);
                System.out.println(json);
                response.setContentType("text/plain");
                response.getWriter().write(json);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.service(req, resp); //To change body of generated methods, choose Tools | Templates.
        //   System.out.println("called");

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //   processRequest(request, response);
        System.out.println("Post");
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    //  @RequestMapping(value="category",method=RequestMethod.GET)
    public ArrayList<String> category(String path) throws IOException {
        Item_category item = new Item_category(path);
        ArrayList<String> category = new ArrayList<>();
            category = item.category_item();
        return category;
    }
}
